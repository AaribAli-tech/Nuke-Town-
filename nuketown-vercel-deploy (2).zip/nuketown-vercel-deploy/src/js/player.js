// ============================================================================
// player.js — first person controller, shooting and damage.
// ============================================================================
import * as THREE from 'three';
import { WEAPON_DEFS } from './weapons.js';
import { clamp, TEAM_A, clampToMap } from './utils.js';
import {
    playGunshot, playDryFire, playReload, playFootstep, playJump, playLand,
    playHurt, playLowHealth, playWeaponSwap
} from './audio.js';
import { SOFT_COVER } from './physics.js';

const EYE_STAND = 1.62, EYE_CROUCH = 1.02;
// Half a head, not half a body: the headroom probe must not be answered by a
// wall that only starts beside your shoulders.
const HEAD_RADIUS = 0.2;
const MAX_DELTA = 180;                       // px per event — spike guard
const PITCH_LIMIT = Math.PI * 0.49;
const _v = new THREE.Vector3(), _v2 = new THREE.Vector3(), _v3 = new THREE.Vector3();

export class Player {
    constructor(camera, cw, viewmodel, ctx) {
        this.camera = camera;
        this.cw = cw;
        this.vm = viewmodel;
        this.ctx = ctx;
        this.team = TEAM_A;
        this.name = 'You';
        // Set by the mode when it has no teams (Free For All, Gun Game). While it
        // is true there are no friendlies to filter out, so nothing is unhittable.
        this.allHostile = false;

        this.position = new THREE.Vector3(0, 0, 0);
        this.velocity = new THREE.Vector3();
        this.yaw = -Math.PI / 2;
        this.pitch = 0;
        this.radius = 0.32;
        this.eyeHeight = EYE_STAND;
        this.currentEye = EYE_STAND;

        this.walkSpeed = 4.9;
        // The town grew south by 44% of its area this pass and the trip to the new
        // row was a slog at the old pace, so sprint is a quarter faster. Walking and
        // crouching are deliberately untouched — crouch is a stealth trade, and the
        // bots keep their own speeds so nobody's difficulty moved.
        this.sprintSpeed = 9.5;
        this.crouchSpeed = 2.4;
        this.accel = 55;
        this.airAccel = 9;
        this.friction = 11;
        this.jumpVel = 6.3;
        this.gravity = 22;

        this.onGround = true;
        this.isCrouching = false;
        this.isSprinting = false;
        this.isADS = false;
        this.baseFov = 78;
        this.sensitivity = 0.0016;       // rad per mouse pixel at 1.00 slider
        this.adsSensScale = 0.75;        // how much of the zoom ratio to cancel

        this.health = 100; this.maxHealth = 100;
        this.alive = true;
        this.lastDamage = -9999;
        this.regenDelay = 4.2;
        this.regenRate = 26;
        this.spawnProtect = 0;

        this.kills = 0; this.deaths = 0; this.assists = 0; this.score = 0;
        this.killStreak = 0; this.matchKills = 0;
        this.headshots = 0; this.longestStreak = 0;

        this.weapons = WEAPON_DEFS.map(d => ({
            ammo: d.magSize, reserve: d.reserve, reloading: false, reloadEnd: 0
        }));
        this.current = 0;
        // What the mode lets you carry. Null is the whole armory — that is the
        // team modes. A one-element list (Gun Game's current rung) means one gun
        // in one slot, and every input that changes the weapon is refused.
        this.loadout = null;
        this.noSwap = false;

        this.lastFire = -9999;
        this.spread = 0;
        this.viewKickX = 0; this.viewKickY = 0;
        this.viewKickVX = 0; this.viewKickVY = 0;
        this.shake = 0; this.shakeDecay = 8;
        this.bobPhase = 0;
        this.footAccum = 0;
        this.lowHealthCue = 0;

        this.keys = Object.create(null);
        this.mouseDown = false;
        this.mouseRight = false;
        this.locked = false;
        // Touch input, written by touch.js and read here. It is deliberately a
        // plain object of already-normalised values rather than a set of synthetic
        // key events: no code below has to care where a thumb came from, and a
        // fake KeyboardEvent would lie about `repeat`, `code` and `isTrusted`.
        this.touch = {
            moveX: 0, moveY: 0,          // -1..1 analog, dead-zoned at the source
            sprint: false, sprintBtn: false,
            fire: false, ads: false,     // held booleans
            jump: false,                 // one-frame pulse, cleared below
            lookDX: 0, lookDY: 0         // pixel deltas, spent once per frame
        };
        this.paused = false;

        this._bind();
    }

    // ── input ───────────────────────────────────────────────────────────────
    _bind() {
        window.addEventListener('keydown', e => {
            if (this.paused) return;
            this.keys[e.code] = true;
            if (e.code === 'Tab') e.preventDefault();
            if (!this.alive) return;
            // `!e.repeat` matters more than it looks. Windows sends key repeat at
            // thirty a second, so holding C flipped the flag all the way through
            // the hold and left you wherever the last flip landed — half the time
            // crouched, with the key doing nothing more, which is exactly what
            // "I can't crouch back up" felt like.
            if (e.code === 'KeyC' && !e.repeat) this.isCrouching = !this.isCrouching;
            if (e.code === 'KeyR') this.startReload();
            if (e.code === 'Digit1') this.useSlot(0);
            if (e.code === 'Digit2') this.useSlot(1);
            if (e.code === 'Digit3') this.useSlot(2);
            if (e.code === 'Digit4') this.useSlot(3);
            if (e.code === 'KeyQ') this.cycleSlot(1);
        });
        window.addEventListener('keyup', e => { this.keys[e.code] = false; });
        window.addEventListener('mousemove', e => {
            if (!this.locked || !this.alive || this.paused) return;
            // Pointer lock occasionally emits a single enormous delta (window
            // focus changes, driver hiccups). Unclamped, that snaps the view
            // right round and feels like the mouse "slipped".
            this._applyLook(clamp(e.movementX, -MAX_DELTA, MAX_DELTA),
                            clamp(e.movementY, -MAX_DELTA, MAX_DELTA));
        });
        window.addEventListener('mousedown', e => {
            if (!this.locked) return;
            if (e.button === 0) this.mouseDown = true;
            if (e.button === 2) this.mouseRight = true;
        });
        window.addEventListener('mouseup', e => {
            if (e.button === 0) this.mouseDown = false;
            if (e.button === 2) this.mouseRight = false;
        });
        window.addEventListener('contextmenu', e => e.preventDefault());
        window.addEventListener('wheel', e => {
            if (!this.locked || !this.alive) return;
            this.cycleSlot(e.deltaY > 0 ? 1 : -1);
        }, { passive: true });
    }

    /**
     * Turn the view by a pixel delta. The mouse and a thumb drag both come
     * through here, so sensitivity, the ADS zoom compensation, the pitch clamp and
     * the viewmodel sway are one rule and not two that drift apart. The clamp on
     * the mouse side (MAX_DELTA) is deliberately not applied to touch: touch.js
     * already accumulates a frame of drag, and a phone does not emit a 4,000 px
     * jump because a driver hiccuped.
     */
    _applyLook(mx, my) {
        // ADS scaling follows the zoom ratio so the same hand movement
        // covers the same on-screen distance whether hipfiring or aiming.
        const zoom = this.isADS ? this.baseFov / Math.max(10, this.camera.fov) : 1;
        const scale = this.sensitivity / (1 + (zoom - 1) * this.adsSensScale);
        this.yaw -= mx * scale;
        this.pitch -= my * scale;
        this.pitch = clamp(this.pitch, -PITCH_LIMIT, PITCH_LIMIT);
        this.vm.addLook(mx, my);
    }

    /** Held-fire from either device. `mouseDown` stays the keyboard/mouse truth. */
    get firing() { return this.mouseDown || this.touch.fire; }

    get def() { return WEAPON_DEFS[this.current]; }
    get mag() { return this.weapons[this.current]; }

    /**
     * The ruleset says what you may hold. `null` is the whole armory; a list of
     * one is Gun Game's rung, where the mode alone decides the weapon. Swapping
     * is legal inside a multi-gun list, never outside it.
     */
    setLoadout(list) {
        // Sanitised here rather than trusted at the call site: a bad index would
        // otherwise reach the HUD as a slot with no weapon in it, and the ladder
        // would promote you onto a gun that has no definition at all.
        const keep = Array.isArray(list)
            ? list.filter(i => Number.isInteger(i) && i >= 0 && i < WEAPON_DEFS.length) : [];
        this.loadout = keep.length ? keep : null;
        this.noSwap = !!this.loadout && this.loadout.length < 2;
        if (this.ctx && this.ctx.onLoadout) this.ctx.onLoadout(this.loadout);
    }

    canHold(i) { return !this.loadout || this.loadout.indexOf(i) >= 0; }

    /** Number keys. A locked loadout answers with the rule, not with a new gun. */
    useSlot(i) {
        if (this.noSwap) return this._refusedSwap();
        this.switchTo(i);
    }

    /** Q and the scroll wheel. */
    cycleSlot(dir) {
        if (this.noSwap) return this._refusedSwap();
        const n = WEAPON_DEFS.length;
        this.switchTo((this.current + (dir > 0 ? 1 : n - 1)) % n);
    }

    _refusedSwap() {
        const cb = this.ctx && this.ctx.onRefusedSwap;
        if (cb) cb();
    }

    switchTo(i) {
        if (i === this.current || i < 0 || i >= WEAPON_DEFS.length) return;
        // Held by the mode's hand, not the player's: the ladder promotes through
        // here, and the loadout it just set is what lets that one through.
        if (!this.canHold(i)) return this._refusedSwap();
        if (!this.vm.requestSwitch(i)) return;
        this.mag.reloading = false;
        this.current = i;
        playWeaponSwap();
    }

    startReload() {
        const m = this.mag, d = this.def;
        if (m.reloading || m.ammo >= d.magSize || m.reserve <= 0) return;
        m.reloading = true;
        m.reloadEnd = performance.now() / 1000 + (d.shellReload ? d.reloadTime * Math.min(4, d.magSize - m.ammo) : d.reloadTime);
        this.vm.startReload({ ...d, reloadTime: m.reloadEnd - performance.now() / 1000 });
        playReload(d.type);
    }

    // ── firing ──────────────────────────────────────────────────────────────
    tryFire(now) {
        if (!this.alive || !this.firing || this.paused) return;
        const d = this.def, m = this.mag;
        if (m.reloading || this.vm.switchT > 0) return;
        if (this.isSprinting && this.vm.sprint > 0.55) return;
        if (m.ammo <= 0) {
            if (now - this.lastFire > 0.35) { playDryFire(); this.lastFire = now; this.startReload(); }
            return;
        }
        const interval = 60 / d.rpm;
        if (now - this.lastFire < interval) return;
        if (d.fireMode !== 'AUTO' && this._semiLatch) return;
        this._semiLatch = d.fireMode !== 'AUTO';

        this.lastFire = now;
        m.ammo--;

        playGunshot(d.audioType);
        this.vm.onFire(d);
        this.ctx.effects.muzzleSmoke(
            this.vm.muzzleWorld(this.camera, _v3),
            _v2.set(0, 0, -1).applyQuaternion(this.camera.quaternion)
        );

        // brass
        const right = _v.set(1, 0, 0).applyQuaternion(this.camera.quaternion);
        const up = _v2.set(0, 1, 0).applyQuaternion(this.camera.quaternion);
        const fwd = _v3.set(0, 0, -1).applyQuaternion(this.camera.quaternion);
        const ejectPos = this.camera.position.clone()
            .addScaledVector(right, 0.22).addScaledVector(up, -0.07).addScaledVector(fwd, 0.28);
        if (!d.shellDelay) this.ctx.effects.shell(ejectPos, right, up, fwd);
        else setTimeout(() => this.alive && this.ctx.effects.shell(
            this.camera.position.clone().addScaledVector(right, 0.2).addScaledVector(up, -0.05), right, up, fwd), d.shellDelay * 1000);

        // recoil: view punch + spread bloom
        const r = d.recoil;
        // A scoped rifle is the one gun where the punch is not just felt, it is
        // seen: the whole view swings off the target and has to be pulled back. The
        // ask was a quarter less of exactly that, so the view punch and the shake
        // shrink while aiming through a scope. What is NOT touched is the spread
        // bloom on the next line — that decides whether the shot earns the kill, and
        // quietly making three guns more accurate is a balance change, not comfort.
        const scopeMul = (this.isADS && d.scope) ? 0.75 : 1;
        const adsMul = (this.isADS ? 0.62 : 1) * scopeMul;
        this.viewKickVY += (r.v * 60) * adsMul;
        this.viewKickVX += (Math.random() - 0.5) * r.h * 110 * adsMul;
        this.spread = Math.min(1, this.spread + (this.isADS ? 0.10 : 0.20));
        this.shake = Math.max(this.shake, r.kick * 0.55 * scopeMul);

        // ── the actual bullets ──
        const origin = this.camera.position.clone();
        const muzzle = this.vm.muzzleWorld(this.camera, new THREE.Vector3());
        const pellets = d.pellets || 1;
        const baseSpread = (this.isADS ? d.adsSpread : d.spread)
            * (1 + this.spread * 1.4)
            * (this._movingFast() ? d.moveSpread : 1);

        for (let p = 0; p < pellets; p++) {
            const dir = new THREE.Vector3(0, 0, -1);
            if (baseSpread > 0) {
                const a = Math.random() * Math.PI * 2;
                const rr = Math.sqrt(Math.random()) * baseSpread;
                dir.x += Math.cos(a) * rr;
                dir.y += Math.sin(a) * rr;
            }
            dir.applyQuaternion(this.camera.quaternion).normalize();
            this._trace(origin, dir, d, muzzle);
        }
    }

    /**
     * Who this weapon may damage. Bots ask the same question of themselves with
     * `isHostile` in ai.js; both have to consult the mode, or a teamless mode ends
     * up with soldiers you can walk through but not shoot.
     */
    canShoot(e) {
        return !!this.allHostile || (!!e && e.team !== this.team);
    }

    _trace(origin, dir, d, muzzleWorld) {
        const world = this.cw.raycast(origin, dir, d.range, SOFT_COVER);
        let wallDist = world ? world.distance : d.range;

        // bots: ray vs. three body spheres, nearest wins
        let best = null, bestT = wallDist, bestHead = false;
        for (const bot of this.ctx.getBots()) {
            if (!bot.alive || !this.canShoot(bot) || bot.spawnProtect > 0) continue;
            const cr = bot.isCrouching;
            const spots = cr
                ? [[0.55, 0.30, false], [0.85, 0.30, false], [1.05, 0.15, true]]
                : [[0.60, 0.30, false], [1.05, 0.32, false], [1.52, 0.155, true]];
            for (const [yOff, rad, head] of spots) {
                const cxx = bot.position.x - origin.x;
                const cyy = bot.position.y + yOff - origin.y;
                const czz = bot.position.z - origin.z;
                const t = cxx * dir.x + cyy * dir.y + czz * dir.z;
                if (t <= 0 || t >= bestT) continue;
                const qx = cxx - dir.x * t, qy = cyy - dir.y * t, qz = czz - dir.z * t;
                if (qx * qx + qy * qy + qz * qz < rad * rad) {
                    best = bot; bestT = t; bestHead = head;
                    break;
                }
            }
        }

        if (best) {
            const hitPoint = origin.clone().addScaledVector(dir, bestT);
            let dmg = d.damage;
            if (bestT > d.falloffStart) {
                dmg *= Math.max(d.falloffMin, 1 - (bestT - d.falloffStart) / (d.range - d.falloffStart));
            }
            if (bestHead) { dmg *= d.headMult; }
            this.ctx.effects.tracer(muzzleWorld, hitPoint, 300);
            this.ctx.effects.blood(hitPoint, dir);
            const killed = best.takeDamage(dmg, this.name);
            this.ctx.onHit(best, killed, bestHead, d);
            if (bestHead) this.headshots += killed ? 1 : 0;
        } else if (world) {
            this.ctx.effects.tracer(muzzleWorld, world.point, 300);
            this.ctx.effects.impact(world.point, world.normal, world.tag, d.type === 'sniper' || d.type === 'shotgun');
        } else {
            this.ctx.effects.tracer(muzzleWorld, origin.clone().addScaledVector(dir, d.range), 300);
        }
    }

    _movingFast() {
        return this.onGround && Math.hypot(this.velocity.x, this.velocity.z) > 2.2;
    }

    // ── damage ──────────────────────────────────────────────────────────────
    takeDamage(amount, fromName, fromPos) {
        if (!this.alive || this.spawnProtect > 0) return;
        this.health -= amount;
        this.lastDamage = performance.now() / 1000;
        this.shake = Math.max(this.shake, 0.16);
        playHurt();

        if (fromPos) {
            const dx = fromPos.x - this.position.x, dz = fromPos.z - this.position.z;
            const worldAngle = Math.atan2(dx, dz);
            const rel = worldAngle - (this.yaw + Math.PI);
            this.ctx.hud.damageDirection(rel);
        }
        this.ctx.hud.hurt(amount);

        if (this.health <= 0) {
            this.health = 0;
            this.alive = false;
            this.deaths++;
            this.longestStreak = Math.max(this.longestStreak, this.killStreak);
            this.killStreak = 0;
            this._startDeathFall(fromPos);
            this.ctx.onPlayerDeath(fromName);
        }
    }

    /** Collapse the view to the ground, tipping away from whoever shot us. */
    _startDeathFall(fromPos) {
        this.deathT = 0;
        this.deathEye = this.currentEye;
        this.deathYaw = this.yaw;
        this.deathPitch = this.pitch;
        let dx, dz;
        if (fromPos) { dx = this.position.x - fromPos.x; dz = this.position.z - fromPos.z; }
        else { dx = Math.random() - 0.5; dz = Math.random() - 0.5; }
        const n = Math.hypot(dx, dz) || 1;
        this.deathDir = { x: dx / n, z: dz / n };
        this.deathRoll = (Math.random() < 0.5 ? -1 : 1) * (0.85 + Math.random() * 0.5);
        this.mouseDown = false;
        this.mouseRight = false;
        this.isADS = false;
        // A thumb still on glass when you die must not keep the corpse shooting,
        // and must not walk away holding fire when it lifts.
        this.touch.fire = false;
        this.touch.ads = false;
        this.touch.moveX = this.touch.moveY = 0;
    }

    /** 0..1 — how far through the collapse we are (used to grade the screen). */
    get deathProgress() {
        if (this.alive || this.deathT === undefined) return 0;
        return clamp(this.deathT / 1.05, 0, 1);
    }

    _deathCam(dt) {
        this.deathT += dt;
        const t = clamp(this.deathT / 1.05, 0, 1);
        const e = t * t * (3 - 2 * t);
        const c = this.camera;

        const groundEye = 0.32;
        const slide = e * 0.6;
        c.position.set(
            this.position.x + this.deathDir.x * slide,
            this.position.y + this.deathEye + (groundEye - this.deathEye) * e,
            this.position.z + this.deathDir.z * slide
        );
        // one soft bounce as the body settles
        c.position.y += Math.max(0, Math.sin(t * Math.PI * 2.4)) * 0.07 * (1 - e);

        c.rotation.order = 'YXZ';
        c.rotation.y = this.deathYaw + this.deathRoll * 0.22 * e;
        c.rotation.x = this.deathPitch + (-0.62 - this.deathPitch) * e;
        c.rotation.z = this.deathRoll * e;

        const targetFov = this.baseFov + 8;
        c.fov += (targetFov - c.fov) * (1 - Math.exp(-3.5 * dt));
        c.updateProjectionMatrix();
    }

    respawn(spawn) {
        this.position.set(spawn.x, 0, spawn.z);
        this.velocity.set(0, 0, 0);
        this.health = this.maxHealth;
        this.alive = true;
        this.spawnProtect = 2.0;
        this.isCrouching = false;
        this.yaw = spawn.x < 0 ? -Math.PI / 2 : Math.PI / 2;
        this.pitch = 0;
        this.viewKickX = this.viewKickY = 0;
        for (let i = 0; i < this.weapons.length; i++) {
            this.weapons[i].ammo = WEAPON_DEFS[i].magSize;
            this.weapons[i].reserve = WEAPON_DEFS[i].reserve;
            this.weapons[i].reloading = false;
        }
        this.vm.cancelReload();
    }

    resetMatch() {
        this.kills = 0; this.deaths = 0; this.assists = 0; this.score = 0;
        this.killStreak = 0; this.matchKills = 0; this.headshots = 0; this.longestStreak = 0;
    }

    // ── frame ───────────────────────────────────────────────────────────────
    update(dt, nowSec) {
        if (this.paused) return;
        const tt = this.touch;
        if (!this.mouseDown && !this.touch.fire) this._semiLatch = false;

        if (this.alive) {
            // A frame's worth of thumb drag, spent here and not in the pointer
            // handler, so look moves at match rate rather than at touch rate.
            if (tt.lookDX || tt.lookDY) {
                this._applyLook(tt.lookDX, tt.lookDY);
                tt.lookDX = tt.lookDY = 0;
            }
            this._move(dt);
            this._reloadTick(nowSec);
            // regen
            if (nowSec - this.lastDamage > this.regenDelay && this.health < this.maxHealth) {
                this.health = Math.min(this.maxHealth, this.health + this.regenRate * dt);
            }
            if (this.health < 35) {
                this.lowHealthCue -= dt;
                if (this.lowHealthCue <= 0) { playLowHealth(); this.lowHealthCue = 1.4; }
            }
            if (this.spawnProtect > 0) this.spawnProtect -= dt;
        } else {
            this.velocity.multiplyScalar(Math.pow(0.02, dt));
            this._deathCam(dt);
            this.vm.update(dt, { aiming: false, sprinting: false, speed: 0, grounded: true, firing: false });
            return;
        }

        // spread recovery
        this.spread = Math.max(0, this.spread - dt * (this.isADS ? 2.6 : 1.8));

        // view kick spring
        const rec = this.def.recoil.recover;
        this.viewKickVY -= this.viewKickY * 150 * dt;
        this.viewKickVX -= this.viewKickX * 150 * dt;
        const dmp = Math.pow(0.0006, dt * (rec / 9));
        this.viewKickVY *= dmp; this.viewKickVX *= dmp;
        this.viewKickY += this.viewKickVY * dt;
        this.viewKickX += this.viewKickVX * dt;

        this._applyCamera(dt);

        // viewmodel
        this.vm.update(dt, {
            aiming: this.isADS,
            sprinting: this.isSprinting,
            speed: Math.hypot(this.velocity.x, this.velocity.z),
            grounded: this.onGround,
            firing: this.firing && this.mag.ammo > 0 && !this.mag.reloading
        });
    }

    _move(dt) {
        const t = this.touch;
        this.isADS = (this.mouseRight || t.ads) && !this.mag.reloading && this.vm.switchT === 0;
        const pushing = t.moveX !== 0 || t.moveY !== 0;
        // `t.sprint` is the stick pushed to its rim (touch.js adds the hysteresis);
        // `t.sprintBtn` is the explicit button, for a run you can hold while the
        // other thumb is busy.
        const wantSprint = ((this.keys['ShiftLeft'] || this.keys['ShiftRight']) ||
            t.sprint || t.sprintBtn) &&
            !this.isADS && !this.isCrouching &&
            (this.keys['KeyW'] || this.keys['KeyA'] || this.keys['KeyD'] || pushing);
        this.isSprinting = wantSprint && this.onGround;

        if (this.keys['ControlLeft']) this.isCrouching = true;

        let maxSpeed = this.isCrouching ? this.crouchSpeed
            : this.isSprinting ? this.sprintSpeed
            : this.isADS ? this.walkSpeed * 0.55 : this.walkSpeed;
        // An analog stick is a throttle, not a switch: pushing it halfway walks,
        // pushing it the rest of the way runs, so a thumb can creep up on an
        // angle without either full sprint or full stop. The keyboard has no such
        // thing, which is why this lives in the touch branch of the input mix.
        const throw01 = Math.hypot(t.moveX, t.moveY);
        if (!this.isCrouching && !this.isADS && !this.isSprinting && throw01 > 0.02)
            maxSpeed = this.walkSpeed + (this.sprintSpeed - this.walkSpeed)
                * Math.min(1, Math.max(0, (throw01 - 0.62) / 0.38));

        const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
        const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
        let wx = 0, wz = 0;
        if (this.keys['KeyW']) { wx += fx; wz += fz; }
        if (this.keys['KeyS']) { wx -= fx; wz -= fz; }
        if (this.keys['KeyD']) { wx += rx; wz += rz; }
        if (this.keys['KeyA']) { wx -= rx; wz -= rz; }
        if (pushing) {
            // Stick up is forward, so the same basis the keys use.
            wx += fx * -t.moveY + rx * t.moveX;
            wz += fz * -t.moveY + rz * t.moveX;
        }
        const wl = Math.hypot(wx, wz);
        if (wl > 0) { wx /= wl; wz /= wl; }

        const a = (this.onGround ? this.accel : this.airAccel) * dt;
        this.velocity.x += (wx * maxSpeed - this.velocity.x) * Math.min(1, a / 4);
        this.velocity.z += (wz * maxSpeed - this.velocity.z) * Math.min(1, a / 4);
        if (wl === 0 && this.onGround) {
            const f = Math.pow(0.0009, dt * (this.friction / 11));
            this.velocity.x *= f; this.velocity.z *= f;
        }

        if ((this.keys['Space'] || t.jump) && this.onGround) {
            this.velocity.y = this.jumpVel;
            this.onGround = false;
            this._airborne = true;
            playJump();
        }
        // A jump is a tap, not a held key: the pulse is spent whether or not it
        // took off, or the first clear frame of ground after landing would launch
        // you again for a press the player let go of long ago.
        if (t.jump) t.jump = false;

        // integrate + resolve
        this.position.x += this.velocity.x * dt;
        this.cw.resolveAxis(this.position, this.radius, this.currentEye, 'x');
        this.position.z += this.velocity.z * dt;
        this.cw.resolveAxis(this.position, this.radius, this.currentEye, 'z');
        // Same rule as the bots: the perimeter is a clamp, not a mesh they can
        // slip through when something else pushes them into it.
        if (clampToMap(this.position, 2.0)) { this.velocity.x *= 0.2; this.velocity.z *= 0.2; }

        this.velocity.y -= this.gravity * dt;
        this.position.y += this.velocity.y * dt;

        const gy = this.cw.groundHeight(this.position.x, this.position.z, this.position.y, this.radius);
        if (this.position.y <= gy) {
            if (this._airborne && this.velocity.y < -5) {
                this.vm.onLand(Math.min(1, -this.velocity.y / 12));
                this.shake = Math.max(this.shake, Math.min(0.2, -this.velocity.y / 60));
                playLand();
            }
            this._airborne = false;
            this.position.y = gy;
            this.velocity.y = 0;
            this.onGround = true;
        } else {
            this.onGround = false;
            if (this.velocity.y > 0) {
                const ceil = this.cw.ceilingHeight(this.position.x, this.position.z, this.position.y + this.currentEye * 0.5, this.radius);
                if (ceil < this.position.y + this.currentEye + 0.1) {
                    this.position.y = ceil - this.currentEye - 0.1;
                    this.velocity.y = 0;
                }
            }
        }

        // Crouch blend. Standing up is refused only where the head genuinely does
        // not fit, and the probe starts above the CROUCHED head: measuring from
        // the waist let the surface you are standing on answer as a ceiling, the
        // check failed, and it then wrote `isCrouching = true` over your own
        // toggle — so a player under a doorframe was locked crouched for good and
        // the key did nothing. The eye height is the thing that changes; whether
        // you are crouching stays your decision.
        let targetEye = this.isCrouching ? EYE_CROUCH : EYE_STAND;
        this.headroomBlocked = false;
        if (!this.isCrouching) {
            const ceil = this.cw.ceilingHeight(this.position.x, this.position.z,
                this.position.y + EYE_CROUCH, HEAD_RADIUS);
            if (Number.isFinite(ceil) && ceil < this.position.y + EYE_STAND + 0.05) {
                targetEye = EYE_CROUCH;
                this.headroomBlocked = true;
            }
        }
        this.eyeHeight = targetEye;
        this.currentEye += (targetEye - this.currentEye) * Math.min(1, dt * 12);

        // footsteps
        const spd = Math.hypot(this.velocity.x, this.velocity.z);
        if (this.onGround && spd > 1.0) {
            this.footAccum += spd * dt;
            const stride = this.isSprinting ? 2.05 : this.isCrouching ? 2.6 : 1.75;
            if (this.footAccum > stride) {
                this.footAccum = 0;
                playFootstep(this._surface(), this.isCrouching ? 0.4 : this.isSprinting ? 1.1 : 0.8);
            }
        } else this.footAccum = Math.min(this.footAccum, 1.2);
    }

    _surface() {
        const p = this.position;
        if (p.y > 0.4) return 'wood';
        if (Math.abs(p.z) < 6.2) return 'asphalt';
        if (Math.abs(p.z) < 7.8) return 'concrete';
        return 'dirt';
    }

    _reloadTick(nowSec) {
        const m = this.mag, d = this.def;
        if (!m.reloading) return;
        if (nowSec >= m.reloadEnd) {
            if (d.shellReload) {
                const want = Math.min(4, d.magSize - m.ammo, m.reserve);
                m.ammo += want; m.reserve -= want;
            } else {
                const want = Math.min(d.magSize - m.ammo, m.reserve);
                m.ammo += want; m.reserve -= want;
            }
            m.reloading = false;
        }
    }

    _applyCamera(dt) {
        const c = this.camera;
        c.position.set(this.position.x, this.position.y + this.currentEye, this.position.z);

        // Walk bob. Deliberately tiny — the viewmodel carries the motion, and
        // bobbing the camera itself is what makes aiming feel slippery.
        const spd = Math.hypot(this.velocity.x, this.velocity.z);
        if (this.onGround && spd > 0.5) this.bobPhase += dt * (5.5 + spd * 1.1);
        const bobAmt = Math.min(1, spd / 5) * (this.isADS ? 0.12 : 1);
        c.position.y += Math.abs(Math.sin(this.bobPhase)) * 0.008 * bobAmt;
        c.position.x += Math.cos(this.bobPhase) * 0.004 * bobAmt * Math.cos(this.yaw);
        c.position.z -= Math.cos(this.bobPhase) * 0.004 * bobAmt * Math.sin(this.yaw);

        if (this.shake > 0.001) {
            c.position.x += (Math.random() - 0.5) * this.shake * 0.5;
            c.position.y += (Math.random() - 0.5) * this.shake * 0.5;
            c.position.z += (Math.random() - 0.5) * this.shake * 0.5;
            this.shake *= Math.pow(0.02, dt * (this.shakeDecay / 8));
        }

        c.rotation.order = 'YXZ';
        c.rotation.y = this.yaw + this.viewKickX;
        c.rotation.x = this.pitch + this.viewKickY;
        // Very slight strafe lean. Anything more and the crosshair visibly
        // slides sideways while you are trying to track a target.
        const strafe = this.velocity.x * Math.cos(this.yaw) - this.velocity.z * Math.sin(this.yaw);
        const rollTarget = -strafe * 0.0022 * (this.isADS ? 0.15 : 1);
        this._roll = (this._roll || 0) + (rollTarget - (this._roll || 0)) * Math.min(1, dt * 6);
        c.rotation.z = this._roll;

        // Frame-rate independent, and fast enough that the FOV lands with the
        // weapon instead of trailing half a second behind it.
        const targetFov = this.isADS ? this.def.adsFov : (this.isSprinting ? this.baseFov + 4 : this.baseFov);
        const lambda = this.isADS ? 3.2 / this.def.adsTime : 12;
        c.fov += (targetFov - c.fov) * (1 - Math.exp(-lambda * dt));
        if (Math.abs(targetFov - c.fov) < 0.02) c.fov = targetFov;
        c.updateProjectionMatrix();
    }

    addShake(v) { this.shake = Math.max(this.shake, v); }
}
